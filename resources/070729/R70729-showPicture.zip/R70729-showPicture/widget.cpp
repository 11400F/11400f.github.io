#include "widget.h"
#include "ui_widget.h"

const int LIM = 9;
const int SPECLIM = 7;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    QImage defaultImage;
    defaultImage.load(":/images/default.png");
    ui->pictureDisplay->setPixmap(QPixmap::fromImage(defaultImage));
    ui->indexDisplay->setText("0/"+QString::number(LIM+1));
    ui->indexDisplay->setAlignment(Qt::AlignRight);
    timer = new QTimer;
    imgidx = 0;
    rand = new QRandomGenerator;
    rand->seed(QTime::currentTime().msec());
    connect(timer, &QTimer::timeout, this, &Widget::timerTimeout);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::timerTimeout(){
    QImage cur; cur.load(":/images/"+QString::number(imgidx)+".png");
    ui->pictureDisplay->setPixmap(QPixmap::fromImage(cur));
    ui->indexDisplay->setText(QString::number(imgidx+1)+"/"+QString::number(LIM+1));
    imgidx = (imgidx == LIM? 0: imgidx+1);
}

void Widget::on_autoButton_clicked()
{
    if(timer->isActive()) return ;
    timer->start(1000);
}

void Widget::on_finishButton_clicked()
{
    timer->stop();
}

void Widget::on_playonceButton_clicked()
{
    timer->singleShot(1000, this, &Widget::timerTimeout);
}

void Widget::on_tonextButton_clicked()
{
    timer->stop();
    QImage cur; cur.load(":/images/"+QString::number(imgidx)+".png");
    ui->pictureDisplay->setPixmap(QPixmap::fromImage(cur));
    ui->indexDisplay->setText(QString::number(imgidx+1)+"/"+QString::number(LIM+1));
    imgidx = (imgidx == LIM? 0: imgidx+1);
}

void Widget::on_mte0Button_clicked()
{
    int curidx = rand->bounded(0, SPECLIM+1);
    QImage cur; cur.load(":/images/spec-"+QString::number(curidx)+".png");
    ui->indexDisplay->setText("?/?");
    ui->pictureDisplay->setPixmap(QPixmap::fromImage(cur));
}

void Widget::on_resetButton_clicked()
{
    QImage cur; cur.load(":/images/default.png");
    ui->pictureDisplay->setPixmap(QPixmap::fromImage(cur));
    ui->indexDisplay->setText("0/"+QString::number(LIM+1));
    imgidx = 0;
}
