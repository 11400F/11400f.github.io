#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QRandomGenerator>
#include <QTime>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_autoButton_clicked();

    void on_finishButton_clicked();

    void on_playonceButton_clicked();

    void on_tonextButton_clicked();

    void on_mte0Button_clicked();

    void timerTimeout();
    void on_resetButton_clicked();

private:
    Ui::Widget *ui;
    QTimer *timer;
    int imgidx;
    QRandomGenerator *rand;
};
#endif // WIDGET_H
