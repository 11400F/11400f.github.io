#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTextEdit>
#include <QString>
#include <QStack>
#include <cmath>
#include <QFontDatabase>
//#include<iostream>



QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_powButton_clicked();

    void on_equalButton_clicked();

    void on_lbracButton_clicked();

    void on_rbracButton_clicked();

    void on_clearButton_clicked();

    void on_amButton_clicked();

    void on_bkspButton_clicked();

    void on_addButton_clicked();

    void on_minusButton_clicked();

    void on_multiButton_clicked();

    void on_divButton_clicked();

    void on_pointButton_clicked();

    void on_button0_clicked();
    void on_button1_clicked();
    void on_button2_clicked();
    void on_button3_clicked();
    void on_button4_clicked();
    void on_button5_clicked();
    void on_button6_clicked();
    void on_button7_clicked();
    void on_button8_clicked();
    void on_button9_clicked();

    void setAllable(bool st);

private:
    Ui::Widget *ui;
    QString str;
};
#endif // WIDGET_H
