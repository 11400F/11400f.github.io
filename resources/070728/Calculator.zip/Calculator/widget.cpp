#include "widget.h"
#include "ui_widget.h"

#define addchar(x) str.append(x); ui->displayArea->setText(str)

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    QFontDatabase::addApplicationFont(QStringLiteral(":/new/prefix1/fonts/Monocraft.ttf"));
    QFontDatabase::addApplicationFont(QStringLiteral(":/new/prefix1/fonts/Saira.ttf"));
    QFontDatabase::addApplicationFont(QStringLiteral(":/new/prefix1/fonts/Unifont.ttf"));

    ui->valDisplay->setAlignment(Qt::AlignRight);
    ui->displayArea->setText("I want to play maimai dx.");
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_powButton_clicked()
{
    addchar("^");
}

void Widget::on_lbracButton_clicked()
{
    addchar("(");
}

void Widget::on_rbracButton_clicked()
{
    addchar(")");
}



void Widget::on_amButton_clicked()
{
    if(str[0] == '-') str.remove(0, 1);
    else str.insert(0, "-");
    ui->displayArea->setText(str);
}

void Widget::on_bkspButton_clicked()
{
    str.chop(1);
    ui->displayArea->setText(str);
}

void Widget::on_addButton_clicked()
{
    addchar("+");
}

void Widget::on_minusButton_clicked()
{
    addchar("-");
}

void Widget::on_multiButton_clicked()
{
    addchar("*");
}

void Widget::on_divButton_clicked()
{
    addchar("/");
}

void Widget::on_pointButton_clicked()
{
    addchar(".");
}

void Widget::on_button0_clicked()
{
    addchar("0");
}

void Widget::on_button1_clicked()
{
    addchar("1");
}

void Widget::on_button2_clicked()
{
    addchar("2");
}

void Widget::on_button3_clicked()
{
    addchar("3");
}

void Widget::on_button4_clicked()
{
    addchar("4");
}

void Widget::on_button5_clicked()
{
    addchar("5");
}

void Widget::on_button6_clicked()
{
    addchar("6");
}

void Widget::on_button7_clicked()
{
    addchar("7");
}

void Widget::on_button8_clicked()
{
    addchar("8");
}

void Widget::on_button9_clicked()
{
    addchar("9");
}
double lstval=0;
void Widget::setAllable(bool st){
    ui->button0->setEnabled(st);
    ui->button1->setEnabled(st);
    ui->button2->setEnabled(st);
    ui->button3->setEnabled(st);
    ui->button4->setEnabled(st);
    ui->button5->setEnabled(st);
    ui->button6->setEnabled(st);
    ui->button7->setEnabled(st);
    ui->button8->setEnabled(st);
    ui->button9->setEnabled(st);
    ui->amButton->setEnabled(st);
    ui->addButton->setEnabled(st);
    ui->minusButton->setEnabled(st);
    ui->multiButton->setEnabled(st);
    ui->divButton->setEnabled(st);
    ui->powButton->setEnabled(st);
    ui->bkspButton->setEnabled(st);
    ui->lbracButton->setEnabled(st);
    ui->rbracButton->setEnabled(st);
    ui->pointButton->setEnabled(st);
    ui->equalButton->setEnabled(st);
}


void Widget::on_clearButton_clicked()
{
    str.clear();
    ui->displayArea->setText(str);
    ui->valDisplay->setText("");
    lstval = 0;
    setAllable(true);
}




QString s;
int getpri(QChar w){
    if(w == '^') return 3;
    else if(w == '*' || w == '/') return 2;
    else return 1;
}
bool illegal = 0;
QStack<double> valstk; QStack<QChar> opestk;
QStack<int> bracket;
bool isope(QChar w){
    return w == '^' || w == '+' || w == '-' || w == '*' || w == '/';
}
bool isnum(QChar w){
    return ('0'<=w&&w<='9')||w=='.'||w=='x';
}
void process(){
    double num2 = valstk.top(); valstk.pop();
    double num1 = valstk.top(); valstk.pop();
    QChar ope = opestk.top(); opestk.pop();
    double res;
//    std::cerr<<"PROCESS: "<<num1<<' '<<num2<<' '<<ope.toLatin1()<<'\n';
    if(ope == '^') res = pow(num1, num2);
    else if(ope == '+') res = num1 + num2;
    else if(ope == '-') res = num1 - num2;
    else if(ope == '*') res = num1 * num2;
    else if(ope == '/') res = num1 / num2;
    valstk.push(res);
}
bool ok;
void Widget::on_equalButton_clicked()
{
    s = str;
    int siz = s.size();
    int am = 1, point = 0; double cur = 0, k = 1;
    for(int i=0;i<siz;i++){
//		cerr<<i<<'\n';
        if(isnum(s[i])){
            if(s[i] == 'x' && isnum(s[i+1])){illegal = 1; break;}
            else if(s[i] == 'x') cur = lstval;
            else if(point == 0 && s[i] == '.') point = 1, k /= 10;
            else if(point == 0) cur = cur * 10, cur += s[i].digitValue();
            else if(point == 1 && s[i] != '.') cur += k * s[i].digitValue(), k /= 10;
            else if(point == 1 && s[i] == '.'){illegal = 1; break;}
        }else if((i == 0 || isope(s[i-1]) || s[i-1] == '(') && s[i] == '-' && isnum(s[i+1])){
            am = -1;
        }else if((s[i] == '(' || isope(s[i])) && ((isope(s[i+1])&&s[i+1]!='-') || s[i+1] == ')')){
            illegal = 1; break;
        }else if(s[i] == '('){
            bracket.push(opestk.size());
        }else if(s[i] == ')'){
            if(bracket.empty()){illegal = 1; break;}
            if(isnum(s[i-1])){
                cur *= am; valstk.push(cur*am); cur = 0, am = 1, point = 0, k = 1;
            }
            int curtop = bracket.top(); bracket.pop();
            while(opestk.size() > curtop) process();
        }else if(isope(s[i])){
//			cerr<<"HERE\n";
            cur = cur * am; am = 1, point = 0, k = 1;
            if(i>0&&isnum(s[i-1])) valstk.push(cur);
            if((opestk.empty()) || (bracket.size() && opestk.size() == bracket.top()) || getpri(opestk.top()) < getpri(s[i])){
                opestk.push(s[i]);
            }else{
                process(); opestk.push(s[i]);
            }
            cur = 0;
        }else{
            illegal = 1; break;
        }
    }
    if(isnum(s[siz-1])) cur *= am, valstk.push(cur), cur=0, am=1;
//	cerr<<"JUMPOUT!\n";
//	cerr<<opestk.size()<<' '<<valstk.size()<<'\n';
    while(opestk.size() && valstk.size()>1){
        process();
    }
    QString valdis;
    if(opestk.size() || (valstk.size() > 1) || bracket.size()) illegal = 1;
    if(illegal) str = "ILLEGAL!", valdis = "ILG";
    else{ str = QString::number(valstk.top());
        if(!isnum(str[0]) && str[0] != '-'){illegal = 1, str = "ERROR!", valdis = "ERR";}
        else str = QString("%1").arg(valstk.top(), 0, 'f', 8), valdis = QString::number(valstk.top());
    }
    while(str.back() == '0') str.chop(1);
    if(str.back() == '.') str.chop(1);
    if(s.isEmpty()) str = "0", valdis = "0", lstval = 0;
    ui->displayArea->setText(str); str = "x";
    ui->valDisplay->setText(valdis);
    if(illegal){
        setAllable(false);
    }
    lstval = valstk.top();
    illegal = 0; opestk.clear(); valstk.clear(); bracket.clear();
}
