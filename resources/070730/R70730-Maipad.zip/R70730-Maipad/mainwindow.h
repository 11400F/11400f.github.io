#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QFileDialog>
#include <QShortcut>
#include <QFontDialog>
#include <QFontDatabase>
#include <QCloseEvent>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void newfileSlot();
    void openfileSlot();
    bool savefileSlot();
    void saveasSlot();
    int SaveWarning();

    void on_textEdit_textChanged();
    void showAboutWindow();
    void setfontSlot();

    void on_autoenterAction_triggered();

    void on_textEdit_cursorPositionChanged();
    void closeEvent(QCloseEvent *event);

private:
    Ui::MainWindow *ui;
    int fileidx=0;
    bool isnewfile=0, isstarted=0;
    bool issaved=1;
    QString filePath;
    QFileInfo fileinfo;
    bool isautoenter;
};
#endif // MAINWINDOW_H
