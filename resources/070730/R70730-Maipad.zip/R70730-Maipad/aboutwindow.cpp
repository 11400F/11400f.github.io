#include "aboutwindow.h"
#include "ui_aboutwindow.h"

aboutWindow::aboutWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::aboutWindow)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Drawer);
    QImage img1; img1.load(":/images/about1.jpg");
    QImage img2; img2.load(":/images/about2.jpg");
    ui->img1Label->setPixmap(QPixmap::fromImage(img1));
    ui->img2Label->setPixmap(QPixmap::fromImage(img2));
    QImage logo; logo.load(":/images/milk-nobg.png");
    ui->logoLabel->setPixmap(QPixmap::fromImage(logo));
}

aboutWindow::~aboutWindow()
{
    delete ui;
}
