#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "aboutwindow.h"

aboutWindow *newwindow;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->textEdit->setReadOnly(true);
    ui->textEdit->setText("来自 MaiPad 的提示：\n\n若欲创建文件请点击【文件 → 新建】或按 Ctrl+N。");
    ui->textEdit->setWordWrapMode(QTextOption::NoWrap); isautoenter = 0;
    ui->positionDisplay->setAlignment(Qt::AlignRight);
    ui->positionDisplay->setText("行 0，列 0");
    newwindow = new aboutWindow;
    QFontDatabase::addApplicationFont(":/fonts/Monocraft.ttf");
    QFontDatabase::addApplicationFont(":/fonts/Saira.ttf");
//    QFontDatabase::addApplicationFont(":/fonts/Unifont.ttf");
    // 文件处理部分

    // 创建快捷键组合
    QShortcut *newShortcut = new QShortcut(QKeySequence("ctrl+n"), this);
    QShortcut *openShortcut = new QShortcut(QKeySequence("ctrl+o"), this);
    QShortcut *saveShortcut = new QShortcut(QKeySequence("ctrl+s"), this);
    QShortcut *saveasShortcut = new QShortcut(QKeySequence("ctrl+shift+s"), this);

    // 连接信号与槽
    connect(newShortcut, &QShortcut::activated, this, &MainWindow::newfileSlot);
    connect(openShortcut, &QShortcut::activated, this, &MainWindow::openfileSlot);
    connect(saveShortcut, &QShortcut::activated, this, &MainWindow::savefileSlot);
    connect(saveasShortcut, &QShortcut::activated, this, &MainWindow::saveasSlot);

    connect(ui->newfileAction, &QAction::triggered, this, &MainWindow::newfileSlot);
    connect(ui->openfileAction, &QAction::triggered, this, &MainWindow::openfileSlot);
    connect(ui->savefileAction, &QAction::triggered, this, &MainWindow::savefileSlot);
    connect(ui->saveasAction, &QAction::triggered, this, &MainWindow::saveasSlot);

    connect(ui->aboutAction, &QAction::triggered, this, &MainWindow::showAboutWindow);

    // 文本处理部分
    QShortcut *copyShortcut = new QShortcut(QKeySequence("ctrl+c"), this);
    QShortcut *pasteShortcut = new QShortcut(QKeySequence("ctrl+v"), this);
    QShortcut *undoShortcut = new QShortcut(QKeySequence("ctrl+z"), this);
    QShortcut *redoShortcut = new QShortcut(QKeySequence("ctrl+y"), this);

    // 连接信号与槽
    connect(copyShortcut, &QShortcut::activated, [this](){ui->textEdit->copy();});
    connect(pasteShortcut, &QShortcut::activated, [this](){ui->textEdit->paste();});
    connect(undoShortcut, &QShortcut::activated, [this](){ui->textEdit->undo();});
    connect(redoShortcut, &QShortcut::activated, [this](){ui->textEdit->redo();});

    // 格式部分
    QShortcut *fontShortcut = new QShortcut(QKeySequence("ctrl+f"), this);

    connect(ui->fontAction, &QAction::triggered, this, &MainWindow::setfontSlot);
    connect(fontShortcut, &QShortcut::activated, this, &MainWindow::setfontSlot);
}

MainWindow::~MainWindow()
{
    delete ui;
}

#define FILETYPE "文本文档 (*.txt);;MaiPad 文件 (*.mai);;所有文件 (*.*)"

void MainWindow::saveasSlot(){
    if(isstarted == 0){
        QMessageBox::warning(this, "来自 MaiPad 的警告", "请先创建或者打开文件。"); return ;
    }
    filePath = QFileDialog::getSaveFileName(this, "你欲保存此文件于何处？", QCoreApplication::applicationDirPath(), FILETYPE);
    if(filePath.isEmpty()) return ;
    fileinfo = QFileInfo(filePath);
    QFile file(filePath);
    file.open(QIODevice::WriteOnly);
    QByteArray ba; ba.append(ui->textEdit->toPlainText());
    file.write(ba); file.close();
    issaved = 1; this->setWindowTitle("MaiPad - " + fileinfo.fileName());
}

bool MainWindow::savefileSlot(){
    if(isstarted == 0){
        QMessageBox::warning(this, "来自 MaiPad 的警告", "请先创建或者打开文件。"); return false;
    }
    // 若用户欲保存此文件，则继续分讨：当前路径是否已经确定。
    if(isnewfile){
        // 则是新文件。需确定路径后保存。
        filePath = QFileDialog::getSaveFileName(this, "你欲保存此文件于何处？", QCoreApplication::applicationDirPath(), FILETYPE);
        if(filePath.isEmpty()) return false;
        fileinfo = QFileInfo(filePath);
    }
    QFile file(filePath);
    file.open(QIODevice::WriteOnly);
    QByteArray ba; ba.append(ui->textEdit->toPlainText());
    file.write(ba); file.close();
    issaved = 1; this->setWindowTitle("MaiPad - " + fileinfo.fileName());
    return true;
}

int MainWindow::SaveWarning(){
    // Yes: 1，No: 2，Cancel: 0;
    int res = QMessageBox::question(this, "来自 MaiPad 的提醒", "你欲不欲保存之前的文件？", QMessageBox::Yes, QMessageBox::No, QMessageBox::Cancel);
    if(res == QMessageBox::Yes){
        return savefileSlot();
    }else if(res == QMessageBox::No) return 2;
    else return 0;
}

void MainWindow::newfileSlot(){
    // 删除之前的文件，新建一个文件。
    if(issaved == 0){
       int res = SaveWarning();
       if(res == 0) return ;
    }
    ui->textEdit->clear();
    ui->textEdit->setReadOnly(false);
    fileidx ++;
    this->setWindowTitle("MaiPad - *新建文本文档 "+QString::number(fileidx)+".txt");
    ui->positionDisplay->setText("行 1，列 1");
    isnewfile = 1; issaved = 0; isstarted = 1;

}



void MainWindow::openfileSlot(){
    QString newfilePath = QFileDialog::getOpenFileName(this, "你欲打开什么文件？", QCoreApplication::applicationDirPath(), FILETYPE);
    if(newfilePath.isEmpty()){
        return ;
    }
    if(issaved == 0){
        int res = SaveWarning();
        if(res == 0) return ;
    }
    isstarted = 0; isnewfile = 0; issaved = 1;
    ui->textEdit->clear();
    filePath = newfilePath;
    fileinfo = QFileInfo(filePath);
    ui->textEdit->setReadOnly(false);
    QFile file(filePath);
    file.open(QIODevice::ReadOnly);
    QByteArray ba = file.readAll();
    ui->textEdit->setText(QString(ba));
    file.close();
    ui->positionDisplay->setText("行 1，列 1");
    isstarted = 1, isnewfile = 0, issaved = 1;
    this->setWindowTitle("MaiPad - " + fileinfo.fileName());
}


void MainWindow::on_textEdit_textChanged()
{
    if(isstarted == 0) return ;
    if(isnewfile){
        this->setWindowTitle("MaiPad - *新建文本文档 "+QString::number(fileidx)+".txt");
    }else this->setWindowTitle("MaiPad - *"+fileinfo.fileName());
    issaved = 0;
}

// 【关于】功能
void MainWindow::showAboutWindow(){
    newwindow->close(); newwindow->show();
}

// 字体处理功能
void MainWindow::setfontSlot(){
    bool ok;
    QFont font = QFontDialog::getFont(&ok, this);
    if(ok) ui->textEdit->setFont(font);
}

void MainWindow::on_autoenterAction_triggered()
{
    isautoenter ^= 1;
    if(isautoenter) ui->textEdit->setWordWrapMode(QTextOption::WrapAnywhere);
    else ui->textEdit->setWordWrapMode(QTextOption::NoWrap);
}

void MainWindow::on_textEdit_cursorPositionChanged()
{

    if(!isstarted) return ;
    QTextCursor cursor = ui->textEdit->textCursor();
    int y = cursor.blockNumber()+1, x = cursor.columnNumber()+1;
    ui->positionDisplay->setText("行 "+QString::number(y)+"，列 "+QString::number(x));
}

void MainWindow::closeEvent(QCloseEvent *event){
    if(issaved == 0){
        int res = SaveWarning();
        if(res == 0) event->ignore();
        else event->accept();
    }else event->accept();
}
