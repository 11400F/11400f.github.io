#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QWidget>
#include <QPainter>
#include <QTimer>
#include <iostream>
#include <QFile>
#include <QCoreApplication>
#include <QJsonParseError>
#include <QJsonObject>
#include <QTime>
#include <QSound>
#include <QJsonArray>
#include <QMessageBox>
#include <QElapsedTimer>
#include <QMediaPlayer>
#include <QDir>
#include <QKeyEvent>

QT_BEGIN_NAMESPACE
namespace Ui { class MainScene; }
QT_END_NAMESPACE

class MainScene : public QWidget
{
    Q_OBJECT

public:
    MainScene(QWidget *parent = nullptr);
    ~MainScene();

    // init
    void initScene();
    // 更新界面信息
    void updatePosition();
    void updateNotes();
    // 开始游戏
    void startGame();
    // 绘制函数，名称不可改
    void paintEvent(QPaintEvent *);

    bool readJson();
    // 放音乐
    void playMusic();
    // 读取 json 和 ogg 路径
    void readPath();
    // reset 清空所有数据重来
    void allClear();
    // 键盘事件
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    // 处理音符判定：1: perfect, 2: great, 3: good, 4: miss
    void processNoteJudgement(int res);


public:
    bool gamestart = 0, ispaused = 0;
    int _all = 0,  _perfect = 0, _great = 0, _good = 0, _miss = 0, _combo = 0, hintplayCount = 0;
    double beatmapSpeed, acc;
    int offset;
private slots:
    void on_pauseButton_clicked();

    void on_continueButton_clicked();

    void on_retryButton_clicked();

    void on_exitButton_clicked();

private:
    Ui::MainScene *ui;
    QTimer *flushTimer, *startWindowTimer;
    QElapsedTimer  *mainTimer,  *lazytimer;
    double lzytime;
    QMediaPlayer *player;
    QString infoPath, audioPath;
};
#endif // MAINSCENE_H
