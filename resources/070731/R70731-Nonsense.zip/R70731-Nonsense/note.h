#ifndef NOTE_H
#define NOTE_H
#include <QPixmap>

class Note
{
public:
    Note();
    void SetPosition(int x, int y);
public:
    QPixmap n_img;
    int n_x, n_y;
    QRect n_rect;
};

#endif // NOTE_H
