#include "mainscene.h"
#include "ui_mainscene.h"
#include "config.h"
#include "tap.h"
#include "hold.h"


struct Beat{
    int x, y, z;
    // 当前位置为 x + y/z 小节
    bool operator < (Beat mai){
        return x+double(y)/z < mai.x+double(mai.y)/mai.z;
    }
    bool operator == (Beat mai){
        return x==mai.x && y==mai.y && z==mai.z;
    }
    bool operator > (Beat mai){
        return x+double(y)/z > mai.x+double(mai.y)/mai.z;
    }
    double operator - (Beat mai){ // 返回中间的小节数。
        return (x+double(y)/z)-(mai.x+double(mai.y)/mai.z);
    }
};
Beat convert(QJsonArray w){
    Beat now;
    now.x = w.at(0).toInt(), now.y = w.at(1).toInt(), now.z = w.at(2).toInt();
    return now;
}


struct Note{
    bool op; //0: tap, 1: hold
    Beat startPos, endPos;
    double startTime, endTime; // 我不会打 endtime
    int column; // 在第几轨道下落
    bool head; // Hold 头是否被处理了
};
struct BPM{
    Beat startPos;
    double bpm;
    double speed(){
        return MINUTE/bpm;
    } // 返回一小节多少秒
};

const int fourK_XDir[4] = {460, 545, 630, 715};
const int fourK_Key[4] = {Qt::Key_D, Qt::Key_F, Qt::Key_J, Qt::Key_K};
QVector<BPM> bpms;

QVector<Note> notes;

QVector<Note> track[4];

QString whichsong;
MainScene::MainScene(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainScene)
{
    ui->setupUi(this);

    initScene();

    beatmapSpeed = 750;
    offset = -120;
    whichsong = "雨露霜雪";
    readPath();
    acc = 0;

    player = new QMediaPlayer;
    mainTimer = new QElapsedTimer;
    flushTimer = new QTimer, startWindowTimer = new QTimer;
    lazytimer = new QElapsedTimer;
    lzytime = 0;
    player->setMedia(QUrl("qrc:/audio/metronome.wav"));player->play();
    if(readJson() == false){
        QMessageBox::warning(this, "来自 MTX4K 的提示", "JSON 读入失败");
        exit(0);
    }

    this->flushTimer = new QTimer();
    flushTimer->start(FLUSH_TIME);
    connect(flushTimer, &QTimer::timeout, [this](){if(ispaused == 0) updatePosition(), update();});
    startWindowTimer->singleShot(2000, this, &MainScene::startGame);

//    startGame();

    // 游戏开始。
    // 开始按键下落且识别键盘。
}



MainScene::~MainScene()
{
    delete ui;
}
BPM curbpm;
double curtim; // curtim: curbpm 的精确时间戳

void SetEndtime(Note &p){
    BPM tmpbpm = curbpm;
    double tmptim = curtim;
    for(auto v: bpms){
        if(v.startPos < p.endPos){
            double diff = v.startPos - tmpbpm.startPos;
            tmptim += tmpbpm.speed() * diff;
            tmpbpm = v;
        }else break;
    }
    p.endTime = tmptim + (p.endPos-tmpbpm.startPos)*tmpbpm.speed();
}

void MainScene::updateNotes(){
//    std::cerr<<"BEGIN\n";
//    std::cerr<<mainTimer->elapsed()<<'\n';
    double nowtime;
    if(gamestart == 0) nowtime = 0;
    else nowtime = (mainTimer->elapsed()-lzytime)/1000.0;
    std::cerr<<nowtime<<'\n';
    while(!notes.empty()){
//        std::cerr<<"!!!\n";
        while(!bpms.empty()&&(*bpms.begin()).startPos<(*notes.begin()).startPos){
//            std::cerr<<"???\n";
            double diff = (*bpms.begin()).startPos - curbpm.startPos;
            curtim += curbpm.speed() * diff;
            curbpm = (*bpms.begin()), bpms.erase(bpms.begin());
        }
        Note curnote = *notes.begin();
        curnote.startTime = curtim + (curnote.startPos-curbpm.startPos)*curbpm.speed();
//        std::cerr<<"CURTIM = "<<curtim<<", CURSTARTTIME = "<<curnote.startTime<<'\n';
//        std::cerr<<curnote.startPos.x<<' '<<curnote.startPos.y<<' '<<curnote.startPos.z<<'\n';
        if(curnote.startTime - nowtime <= APPEAR_LIM){
            notes.erase(notes.begin());
            std::cerr<<" ADD NOTE "<<curnote.startPos.x<<' '<<curnote.startPos.y<<' '<<curnote.startPos.z<<'\n';

            if(curnote.op == 1){
                SetEndtime(curnote);
                track[curnote.column].push_back(curnote);
            }else{
                curnote.endTime = curnote.startTime;
                track[curnote.column].push_back(curnote);
            }
        }else break;
    }
//    std::cerr<<"END\n";
}
void MainScene::updatePosition(){
    // 按键生成、下落。
    if(gamestart == 0) return ;
    updateNotes();
}


void MainScene::startGame()
{
    QEventLoop eventloop;
    update();
    auto cur = *bpms.begin();
//    int z = cur.startPos.z;

    //// 这里初始化所需的 notes
    curbpm = *bpms.begin(); bpms.erase(bpms.begin()); curtim = 0;
    updateNotes(); update();
    ////

    std::cerr<<"Beats: "<<cur.speed()<<'\n';
    double cspeed = cur.speed()*1000;

    QTimer::singleShot(cspeed, &eventloop, SLOT(quit()));
    for(int i=1;i<=4;i++){
        QTimer::singleShot(cspeed, &eventloop, SLOT(quit()));
        eventloop.exec();
        std::cerr<<i<<'\n';
        player->stop();
        player->setMedia(QUrl("qrc:/audio/metronome.wav"));
        player->play();
    }
    QTimer::singleShot(cspeed, &eventloop, SLOT(quit()));
    eventloop.exec();
    if(offset > 0){
        mainTimer->start();
        gamestart = 1;
        playMusic();
    }else{
        playMusic();
        QTimer::singleShot(-offset, &eventloop, SLOT(quit()));
        eventloop.exec();
        mainTimer->start();
        gamestart = 1;
    }
}


void MainScene::initScene()
{
    this->setFixedSize(WIDGET_WIDTH, WIDGET_HEIGHT);
    this->setWindowTitle(WIDGET_TITLE);
    this->setMaximumSize(WIDGET_WIDTH, WIDGET_HEIGHT);
    this->setMinimumSize(WIDGET_WIDTH, WIDGET_HEIGHT);
    QPalette pe;
    pe.setColor(QPalette::WindowText, Qt::white);
    ui->accLabel->setPalette(pe);
    ui->songinfoLabel->setPalette(pe);
    ui->continueButton->hide();
    ui->retryButton->hide();
    ui->exitButton->hide();
    ui->pausedLabel->hide();
    ui->comboLabel->hide();
    ui->judgementLabel->hide();
    pe.setColor(QPalette::WindowText, Qt::cyan);
    ui->comboLabel->setPalette(pe);
    ui->judgementLabel->setAlignment(Qt::AlignHCenter);
    ui->comboLabel->setAlignment(Qt::AlignHCenter);
}


void MainScene::processNoteJudgement(int res)
{
    QPalette pe;
    if(res == 1) _perfect ++, pe.setColor(QPalette::WindowText, Qt::yellow), ui->judgementLabel->setText("PERFECT");
    else if(res == 2) _great ++, pe.setColor(QPalette::WindowText, Qt::magenta), ui->judgementLabel->setText("GREAT");
    else if(res == 3) _good ++, pe.setColor(QPalette::WindowText, Qt::green), ui->judgementLabel->setText("GOOD");
    else _miss ++, pe.setColor(QPalette::WindowText, Qt::gray), ui->judgementLabel->setText("MISS");
    if(res != 4) _combo ++;
    else _combo = 0;
    _all ++;
    acc = double(_perfect+0.5*_great+0.3*_good)/_all*100;
    ui->accLabel->setText("ACC: "+QString::number(acc, 'f', 2) + " %");
    if(_combo == 0) ui->comboLabel->hide();
    else ui->comboLabel->show(), ui->comboLabel->setText(QString::number(_combo));
    ui->judgementLabel->setPalette(pe);
    ui->judgementLabel->show();
}

void MainScene::paintEvent(QPaintEvent *)
{
    double paintTime = (mainTimer->elapsed()-lzytime)/1000.0;
    QPainter curPaint(this);
    curPaint.drawPixmap(0, 0, QPixmap::fromImage(QImage(BG_DARK_DIR)));
//    for(auto it = track.begin(); it != track.end(); it ++){
//        auto cur = *it;
//        std::cerr<<"!!! "<<cur.n_x<<' '<<cur.n_y<<'\n';
//        curPaint.drawPixmap(cur.n_x, cur.n_y, cur.n_img);
//    }
    curPaint.drawPixmap(fourK_XDir[0], 0, QPixmap::fromImage(QImage(NOTE_DIR)));
    for(int i=0;i<4;i++){
        if(gamestart == 0) continue;
        for(auto v: track[i]){
            if(v.op == 0){
                int curX = fourK_XDir[i];
                int curY = TRACK_HEIGHT - (v.startTime - paintTime) * beatmapSpeed;
//                std::cerr<<"CURY = "<<curY<<'\n';
                if(curY > WIDGET_HEIGHT){
                    track[i].erase(track[i].begin());
                    processNoteJudgement(4);
                    continue;
                }
//                std::cerr<<"TAP! "<<curX<<' '<<curY<<'\n';
                curPaint.drawPixmap(curX, curY, QPixmap::fromImage(QImage(NOTE_DIR)));
            }else{
                int curX = fourK_XDir[i];
                int curY = TRACK_HEIGHT - (v.startTime - paintTime) * beatmapSpeed;
                int endY = TRACK_HEIGHT - (v.endTime - paintTime) * beatmapSpeed;
                if(endY > WIDGET_HEIGHT){
                    track[i].erase(track[i].begin());
                    processNoteJudgement(4);
                    continue;
                }
//                std::cerr<<"HOLD! "<<curX<<' '<<curY<<' '<<endY<<'\n';
                if(v.head == 0){
                    curPaint.drawPixmap(curX, curY, QPixmap::fromImage(QImage(HOLD_BEG_DIR)));
    //                std::cerr<<"???\n";
                    curY -= 10;
    //                std::cerr<<"CUR CURY = "<<curY<<'\n';
                }else{
                    curY = TRACK_HEIGHT;
                }
                while(curY > -10 && curY > endY) curPaint.drawPixmap(curX, curY, QPixmap::fromImage(QImage(HOLD_MID_DIR))), curY -= 10;
                if(endY > -10) curPaint.drawPixmap(curX, endY, QPixmap::fromImage(QImage(HOLD_END_DIR)));
            }
        }
    }
}



bool MainScene::readJson()
{
    QFile file(infoPath);
    file.open(QIODevice::ReadOnly);
    QByteArray ba = file.readAll();
    file.close();
    QString cont = QString(ba);
    QJsonParseError err;
    QJsonDocument curjson = QJsonDocument::fromJson(ba, &err);
    if(err.error != QJsonParseError::NoError) return false;
    QJsonObject rootobj = curjson.object();

    // 处理 time
    QJsonArray timeArray = rootobj.value("time").toArray();
    int timesiz = timeArray.size();
    for(int i=0;i<timesiz;i++){
        QJsonObject curobject = timeArray.at(i).toObject();
        Beat curbeat = convert(curobject.value("beat").toArray());
        double curbpm = curobject.value("bpm").toDouble();
//        std::cerr<<"CURBPM: "<<curbpm<<'\n';
        bpms.push_back({curbeat, curbpm});
    }
    // 处理 note
    QJsonArray noteArray = rootobj.value("note").toArray();
    int notesiz = noteArray.size();
    // 若不存在: QJsonValue::isUndefined()
    for(int i=0;i<notesiz-1;i++){
        QJsonObject curobject = noteArray.at(i).toObject();
        Beat curbeat = convert(curobject.value("beat").toArray());
        int column = curobject.value("column").toInt();
        if(curobject.value("endbeat").isUndefined()){
            notes.push_back({0, curbeat, curbeat, 0, 0, column, 0}); // 目前不知道精确下落时间就用 0 代替
        }else{
            Beat curbeatend = convert(curobject.value("endbeat").toArray());
            notes.push_back({1, curbeat, curbeatend, 0, 0, column, 0});
        }
    }
//    for(auto v: notes){
//        std::cerr<<v.op<<' '<<v.startPos.x<<' '<<v.startPos.y<<' '<<v.startPos.z<<'\n';
//    }
    // 这里 note 的最后一项就不处理了。
    // 处理 meta，即歌曲元数据
    QJsonObject metaObject = rootobj.value("meta").toObject();
    QJsonObject songInfo = metaObject.value("song").toObject();
    ui->songinfoLabel->setText(
        "曲名："+songInfo.value("title").toString()+"\n"+
        "作者："+songInfo.value("artist").toString()+"\n"+
        "谱面等级："+metaObject.value("version").toString()+"\n"+
        "谱师："+metaObject.value("creator").toString()
    );
    return true;
}

void MainScene::playMusic(){

    if(offset > 0){
        QEventLoop eventloop;
        QTimer::singleShot(offset, &eventloop, SLOT(quit()));
        eventloop.exec();
    }
    player->setMedia(QUrl::fromLocalFile(audioPath));
    player->setVolume(100);
    player->play();
}

void MainScene::readPath()
{
    QDir dir(QCoreApplication::applicationDirPath() + "/song/"+whichsong+"/");
    QFileInfoList fileList = dir.entryInfoList(QStringList() << "*.json");
    if(fileList.empty()) fileList = dir.entryInfoList(QStringList() << "*.mc");
    infoPath = fileList.at(0).absoluteFilePath();
    fileList = dir.entryInfoList(QStringList() << "*.ogg");
    audioPath = fileList.at(0).absoluteFilePath();
}



void MainScene::on_pauseButton_clicked()
{
    if(gamestart == 0) return ;
    lazytimer->start();
    ispaused = 1;
    ui->continueButton->show();
    ui->exitButton->show();
    ui->retryButton->show();
    ui->pausedLabel->show();
    ui->pauseButton->hide();
    player->pause();
}
#define min(x, y) ((x)<(y)?(x):(y))

void MainScene::on_continueButton_clicked()
{
    auto curposition = player->position();
    auto delta = min(curposition, THREE_SEC);
    lzytime += lazytimer->elapsed()+delta;
    ui->continueButton->hide();
    ui->exitButton->hide();
    ui->retryButton->hide();
    ui->pausedLabel->hide();
    ui->pauseButton->show();
    player->play();
    player->setPosition(curposition-delta);

    ispaused = 0;
}

void MainScene::on_retryButton_clicked()
{
    ui->continueButton->hide();
    ui->exitButton->hide();
    ui->retryButton->hide();
    ui->pausedLabel->hide();
    ui->pauseButton->show();
    allClear();
}

void MainScene::on_exitButton_clicked()
{
    exit(0);
}

void MainScene::allClear(){
    bpms.clear(), notes.clear();
    for(int i=0;i<4;i++) track[i].clear();
    gamestart = 0, ispaused = 0;
    _all = 0,  _perfect = 0, _great = 0, _good = 0, _miss = 0;
    lzytime = 0;
    player = new QMediaPlayer;
    mainTimer = new QElapsedTimer;
    flushTimer = new QTimer, startWindowTimer = new QTimer;
    lazytimer = new QElapsedTimer;

    if(readJson() == false){
        QMessageBox::warning(this, "来自 MTX4K 的提示", "JSON 读入失败");
        exit(0);
    }

    this->flushTimer = new QTimer();
    flushTimer->start(FLUSH_TIME);
    startWindowTimer->singleShot(2000, this, &MainScene::startGame);

}



#define resetDeltalabel() ui->deltaLabel->setText("Delta: xx ms")

void MainScene::keyPressEvent(QKeyEvent *event)
{

    double nowtime = (mainTimer->elapsed()-lzytime);

    for(int i=0;i<4;i++){
        if(event->key() != fourK_Key[i]) continue;
        if(event->isAutoRepeat()){
            // 若这个键被长按了
            continue;
        }else{
            if(track[i].empty() || (*track[i].begin()).startTime*1000 - nowtime >= MISS) continue;
            else{
                double diff = (*track[i].begin()).startTime*1000-nowtime;
                if(-PERFECT<=diff&&diff<=PERFECT) processNoteJudgement(1);
                else if(-GREAT<=diff&&diff<=GREAT) processNoteJudgement(2);
                else if(-GOOD<=diff&&diff<=GOOD) processNoteJudgement(3);
                else processNoteJudgement(4);
                ui->deltaLabel->setText("Delta: "+QString::number(diff)+" ms");
                if((*track[i].begin()).op == 0){
                    track[i].erase(track[i].begin());
                    track[i].shrink_to_fit();
                }else{
                    (*track[i].begin()).head = 1;
                }
            }
        }
    }
}

void MainScene::keyReleaseEvent(QKeyEvent *event)
{
    double nowtime = (mainTimer->elapsed()-lzytime);

    for(int i=0;i<4;i++){
        if(event->key() != fourK_Key[i]) continue;
        if(event->isAutoRepeat()){
            // 若这个键被长按了
            continue;
        }else{
            if(track[i].empty() || (*track[i].begin()).endTime*1000 - nowtime >= END_MISS || (*track[i].begin()).op == 0) continue;
            else{
                double diff = (*track[i].begin()).endTime*1000-nowtime;
                if(-END_PERFECT<=diff&&diff<=END_PERFECT) processNoteJudgement(1);
                else if(-END_GREAT<=diff&&diff<=END_GREAT) processNoteJudgement(2);
                else if(-END_GOOD<=diff&&diff<=END_GOOD) processNoteJudgement(3);
                else processNoteJudgement(4);
                ui->deltaLabel->setText("Delta: "+QString::number(diff)+" ms");
                track[i].erase(track[i].begin());
                track[i].shrink_to_fit();
            }
        }
    }
}
