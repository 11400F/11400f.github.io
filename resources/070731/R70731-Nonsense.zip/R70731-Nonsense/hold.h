#ifndef HOLD_H
#define HOLD_H
#include <QPixmap>

class Hold
{
public:
    Hold();
    void SetPosition(int x, int y);
public:
    QPixmap n_img;
    int n_x, n_y;
    QRect n_rect;
};

#endif // HOLD_H
