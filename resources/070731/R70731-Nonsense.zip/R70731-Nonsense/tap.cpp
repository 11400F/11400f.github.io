#include "tap.h"
#include "config.h"

Tap::Tap()
{
    n_x = 0, n_y = 0;
    n_img.load(NOTE_DIR);
    n_rect.setHeight(NOTE_HEIGHT), n_rect.setWidth(NOTE_WIDTH);
    n_rect.moveTo(n_x, n_y);
}

void Tap::SetPosition(int x, int y)
{
    n_x = x, n_y = y;
    n_rect.moveTo(x, y);
}

