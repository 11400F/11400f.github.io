#ifndef CONFIG_H
#define CONFIG_H

#define WIDGET_WIDTH 800
#define WIDGET_HEIGHT 600

#define WIDGET_TITLE "MTX4K"

#define NOTE_WIDTH 75
#define NOTE_HEIGHT 10
#define NOTE_DIR ":/images/note.png"
#define BG_DIR ":/images/bg.png"
#define BG_DARK_DIR ":/images/bg-dark.png"

#define HOLD_BEG_DIR ":/images/hold-beg.png"
#define HOLD_MID_DIR ":/images/hold-mid.png"
#define HOLD_END_DIR ":/images/hold-end.png"

#define THREE_SEC 3 * 1000
#define MINUTE 60
#define FLUSH_TIME 8
#define TRACK_HEIGHT 532
#define PERFECT 70
#define GREAT 120
#define GOOD 160
#define MISS 160

#define END_PERFECT 100
#define END_GREAT 140
#define END_GOOD 200
#define END_MISS 200

#define APPEAR_LIM (TRACK_HEIGHT/beatmapSpeed)
#endif // CONFIG_H
